<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package cr12_moaz_sabri_traveler
 */

?>

	<footer id="colophon" class="site-footer bg-dark">
		<center class="site-info">
			<p>
				Copyright &copy; <?php bloginfo( 'name' ); ?> <span class="sep"> | </span> <?php the_date(); ?>
				<?php echo date_i18n( get_option( 'date_format', 'Y' )); ?>
			</p>
		</center><!-- .site-info -->
	</footer><!-- #colophon -->

<?php wp_footer(); ?>

</body>
</html>
