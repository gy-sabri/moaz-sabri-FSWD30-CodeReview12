<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package cr12_moaz_sabri_traveler
 */

get_header(); 
include(get_template_directory() . '/inc/breadcrumb.php'); 

?>

<div class="cont">
	<div class="row ">
		<div id="content" class="col-md-9 site-content">


			<div id="primary" class="content-area">
            <div class="author-post mt-2">
                <div class="row">
                    <div class="col-md-5">
                        <?php 
                            $avatar_arguments = array(
                                'class' => 'user-img'
                            );

                            echo get_avatar(get_the_author_meta('ID'), 250, '', 'User Avatar', $avatar_arguments);
                        ?>
                    </div>
                    <div class="col-md-7">
                        <p>First Name: <?php the_author_meta( 'first_name') ?></p>
                        <p>Last Name: <?php the_author_meta( 'last_name') ?></p>
                        <p>Nickname: <?php the_author_meta( 'nickname') ?></p>
                        <hr>
                        <?php 
                        if (the_author_meta( 'description')) { ?>
                            <p>Description: <br><?php the_author_meta( 'description') ?></p>
                        <?php } else {
                            echo 'Sorry don`t have description';    
                        } ?>
                        <hr>
                        <div class="row">
                            <div class="col-md-6">
                                <p>Posts Count: <span><?php echo count_user_posts(get_the_author_meta('ID')) ?></span></p>
                            </div>
                            <div class="col-md-6">
                                <p>Comments Count: <?php
                                    $commentscounts = array(
                                        'user_id'   => get_the_author_meta( 'ID'),
                                        'count'     => true
                                    );
                                    echo get_comments($commentscounts);
                                ?></p>
                            </div>
                        </div>
                        
                    </div>
                </div><!-- End Row -->
                
                <?php the_author_meta( 'first_name') ?>
            </div>
				<main id="main" class="site-main">

				<?php
				if ( have_posts() ) :

					if ( is_home() && !is_front_page() ) : ?>
						<header>
							<h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1>
						</header>
					<?php
					endif;

					/* Start the Loop */
					while ( have_posts() ) : the_post();?>

						<!-- /*
						* Include the Post-Format-specific template for the content.
						* If you want to override this in a child theme, then include a file
						* called content-___.php (where ___ is the Post Format name) and that will be used instead.
						*/ -->
						<div class="author-post mt-2">
							<div class="row">
								<div class="col-md-6">
									<h2 class="posts-title"><a href="<?php the_permalink(); // href to a specific blog post ?>"><?php the_title(); // blog post title ?></a></h2>
									<?php the_post_thumbnail( '', ['class' => 'img-post', 'title' => 'Post Img'] ) // blog post img ?>
								</div>
								<div class="col-md-6">
									<span class="post-user-icon"><?php the_author_posts_link() ?> <i class="fa fa-user"></i></span>
									<span><i class="fa fa-calendar"></i> <?php the_date( 'A G:i l F j, Y' ); // blog post date ?></span>
									<p><?php the_excerpt() // blog post Content ?></p>
									<hr>
									<p><i class="fa fa-sitemap"></i> <?php the_category(' , ') // category?></p>
									<p><i class="fa fa-tags"></i> <?php the_tags(' , ') // tags?></p>
								</div>
							</div>
						</div>

					<?php endwhile;
						else :
							get_template_part( 'template-parts/content', 'none' );
						endif; 
					?>
				</main><!-- #main -->

			</div><!-- #primary -->

		</div><!-- #content -->
<?php
get_sidebar();
get_footer();
